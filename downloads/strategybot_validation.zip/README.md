# Standalone StrategyBot candidate

Submit only `bot.py` if you choose to use this candidate. It does not import any other bundled file.

See REPORT.md for the measured comparisons, raid-freeze fix, limitations and commands. The `references/` copies preserve the exact inputs used in the comparison. Nothing was committed, pushed, or changed in the repository.

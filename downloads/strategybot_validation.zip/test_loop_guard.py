"""Regressions for the three-stay/two-freeze/four-cooldown trap."""
import copy
from pathlib import Path
import unittest
from simulate import Game, load_bot

HERE = Path(__file__).resolve().parent


class RaidLockTests(unittest.TestCase):
    def setUp(self):
        self.bot=load_bot(HERE/'bot.py','loop_guard_bot')
        self.g=Game([[2]*8 for _ in range(8)])
        self.g.positions[1]=(3,3)
        self.g.board[3][3].owner=2
        self.g.board[3][3].is_upgraded=True

    def act(self,force=False):
        state=self.g.state(1)
        if force:state.legal_actions=['STAY']
        before=copy.deepcopy(state)
        action=self.bot.act(state)
        self.assertIn(action,state.legal_actions)
        self.assertEqual(state,before)
        return action

    def first_catch(self):
        for _ in range(2):
            self.assertEqual(self.act(True),'STAY')
            self.g.step({1:'STAY'})
        self.assertEqual(self.act(True),'STAY')
        self.g.step({1:'STAY',2:'SHIELD'})
        self.assertEqual(self.g.frozen[1],2)

    def test_escapes_on_first_thaw_and_does_not_repeat_loop(self):
        self.first_catch()
        for _ in range(2):
            self.assertEqual(self.act(),'STAY')
            self.g.step({1:'STAY'})
        self.assertEqual(self.g.frozen[1],0)
        action=self.act()
        self.assertIn(action,('NORTH','EAST','SOUTH','WEST'))
        self.g.step({1:action})
        self.assertNotEqual(self.g.positions[1],(3,3))
        # Adversarial defender saves every shield for the completing stay.
        for _ in range(22):
            action=self.act()
            r,c=self.g.positions[1]
            cell=self.g.board[r][c]
            defend=('SHIELD' if cell.owner==2 and self.g.progress[1]>=2
                    and 'SHIELD' in self.g.legal_actions(2) else 'STAY')
            self.g.step({1:action,2:defend})
        self.assertEqual(self.bot._MEM.raid_interrupts[(2,27)],1)
        self.assertGreater(sum(c.owner==1 and not c.is_home for row in self.g.board for c in row),0)

    def context(self,turn=10,last_shield=9):
        self.g.positions[1]=(3,4)
        snap=self.bot.Snap(self.g.state(1))
        mem=self.bot.Memory(snap)
        mem.turn=turn
        mem.last_shield[2]=last_shield
        mem.raid_interrupts[(2,27)]=1
        return self.bot._build_ctx(mem,snap)

    def test_requires_window_for_movement_and_all_three_stays(self):
        c=self.context()
        self.assertFalse(self.bot._raid_locked(c,27,self.bot.RAID2,1,0,10,c.s.own))
        self.assertIsNotNone(self.bot._evaluate(c,27,self.bot.RAID2,1,0,10,c.s.own,c.s.lvl))
        self.assertTrue(self.bot._raid_locked(c,27,self.bot.RAID2,2,0,10,c.s.own))
        self.assertIsNone(self.bot._evaluate(c,27,self.bot.RAID2,2,0,10,c.s.own,c.s.lvl))
        c=self.context(turn=11)
        self.assertTrue(self.bot._raid_locked(c,27,self.bot.RAID2,1,0,11,c.s.own))

    def test_guard_applies_to_another_upgraded_cell_of_same_owner(self):
        self.g.board[4][4].owner=2
        self.g.board[4][4].is_upgraded=True
        c=self.context(turn=20,last_shield=3)
        self.assertTrue(self.bot._raid_locked(c,36,self.bot.RAID2,1,0,20,c.s.own))
        self.assertFalse(self.bot._raid_locked(c,36,self.bot.RAID1,1,0,20,c.s.own))

    def test_safe_early_stays_do_not_train_down_urgent_shield_risk(self):
        for _ in range(2):
            self.act(True)
            self.g.step({1:'STAY'})
        self.act(True)
        self.assertEqual(self.bot._MEM.stats[2]['urgent_opp'],0)
        self.assertAlmostEqual(self.bot._rho_urgent(self.bot._MEM,2),.65)
        self.g.step({1:'STAY',2:'SHIELD'})
        self.act()
        stats=self.bot._MEM.stats[2]
        self.assertEqual((stats['urgent_opp'],stats['urgent_sh']),(1,1))
        urgent=self.bot._rho_urgent(self.bot._MEM,2)
        self.assertGreater(urgent,.65)
        for _ in range(2):
            self.g.step({1:'STAY'})
            self.act(True)
        self.assertAlmostEqual(self.bot._rho_urgent(self.bot._MEM,2),urgent)
        self.assertEqual(self.bot._MEM.prog[1],0)

    def test_no_illegal_escape_when_surrounded(self):
        self.g.positions[1]=(0,3)
        self.g.positions[2],self.g.positions[3],self.g.positions[4]=(0,2),(0,4),(1,3)
        self.g.board[0][3].owner,self.g.board[0][3].is_upgraded=2,True
        snap=self.bot.Snap(self.g.state(1));mem=self.bot.Memory(snap)
        mem.turn=20;mem.raid_interrupts[(2,3)]=1
        self.bot._MEM=mem
        action=self.act()
        self.assertEqual(action,'STAY')

    def test_new_game_clears_raid_locks(self):
        self.first_catch();self.act()
        self.assertTrue(self.bot._MEM.raid_interrupts)
        state=Game([[2]*8 for _ in range(8)]).state(1)
        self.bot.act(state)
        self.assertFalse(self.bot._MEM.raid_interrupts)


if __name__=='__main__':unittest.main()

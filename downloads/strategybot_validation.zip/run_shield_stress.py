from arena import run_match
from pathlib import Path
import hashlib,json
results={}
for path in ['bot.py','references/bot_dev.py','references/mbot.py','references/bot_current.py']:
 rows=[];timing=[]
 for seed in range(2000,2008):
  for seat in range(4):
   files=['baseline:patient']*4;files[seat]=path
   scores,times,stats=run_match(files,seed,telemetry=True)
   own=scores[seat];others=[s for i,s in enumerate(scores) if i!=seat]
   rows.append({'seed':seed,'seat':seat+1,'scores':scores,'rank':1+sum(s>own for s in others),'pairwise_points':sum(1 if own>s else .5 if own==s else 0 for s in others),'frozen_turns':stats[seat]['frozen_turns'],'raid_interruptions':stats[seat]['raid_interruptions']})
   timing.extend(times[seat])
 summary={'games':len(rows),'wins':sum(r['rank']==1 for r in rows),'pairwise':sum(r['pairwise_points'] for r in rows)/(3*len(rows)),'mean_score':sum(r['scores'][r['seat']-1] for r in rows)/len(rows),'mean_frozen_turns':sum(r['frozen_turns'] for r in rows)/len(rows),'max_catches_same_cell':max((v for r in rows for v in r['raid_interruptions'].values()),default=0),'max_ms':max(timing)*1000}
 results[path]={'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'summary':summary,'results':rows}
 print(path,json.dumps(summary),flush=True)
 Path('holdout_shields.json').write_text(json.dumps(results,indent=2)+'\n')

"""Independent public-state opponent that saves SHIELD for completing raids."""
from types import SimpleNamespace
from simulate import Baseline


class PatientGuardian:
    def __init__(self, seed=0):
        self.base = Baseline('fortress', seed)
        self.prev = None
        self.progress = {}

    def act(self, state):
        cells = [c for row in state.board for c in row]
        positions = {c.occupant:i for i,c in enumerate(cells) if c.occupant}
        current = {b:(p,cells[p].owner,cells[p].is_upgraded,cells[p].is_frozen)
                   for b,p in positions.items()}
        progress = {}
        if self.prev:
            for b,now in current.items():
                before = self.prev.get(b)
                if before and now[:3] == before[:3] and not now[3] and not before[3]:
                    p=self.progress.get(b,0)+1
                    need=3 if now[1]==b or now[2] else 1
                    progress[b]=p if p<need else 0
        self.prev,self.progress=current,progress
        urgent=False
        for b,p in positions.items():
            c=cells[p]
            if b != state.bot_id and c.owner==state.bot_id and not c.is_home and not c.is_frozen:
                if not c.is_upgraded or progress.get(b,0)>=2:
                    urgent=True
        legal=list(state.legal_actions)
        if 'SHIELD' in legal:
            legal=['SHIELD'] if urgent else [a for a in legal if a!='SHIELD']
        view=SimpleNamespace(board=state.board,bot_id=state.bot_id,
                             is_priority_token=state.is_priority_token,legal_actions=legal)
        return self.base.act(view)

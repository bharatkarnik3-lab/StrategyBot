"""Zone Rush project planner. Single-file, standard-library submission.

Replans from public observations every turn. Search predicts our projects, while
rival positions and risk estimates are approximations rather than future facts.
"""
from collections import deque
from time import perf_counter

DEPTH = 6
WIDTH = 24
ARMOR = 0.55
RAID_WEIGHT = 0.35
SHIELD_RISK = 0.75
TIME_BUDGET = 0.065
_MEMORY = {}
MOVES = (('NORTH', -1, 0), ('EAST', 0, 1), ('SOUTH', 1, 0), ('WEST', 0, -1))
NEIGHBORS = tuple(tuple((a, (i // 8 + dr) * 8 + i % 8 + dc)
                         for a, dr, dc in MOVES
                         if 0 <= i // 8 + dr < 8 and 0 <= i % 8 + dc < 8)
                  for i in range(64))
DISTANCE = tuple(tuple(abs(i//8-j//8)+abs(i%8-j%8) for j in range(64)) for i in range(64))


def observe(cells, me, legal, priority):
    positions = {cell[2]: i for i, cell in enumerate(cells) if cell[2]}
    memory = _MEMORY.setdefault(me, {'turn': 0, 'old': None, 'progress': {},
                                     'cooldown': {}, 'reaction': {}, 'token': None})
    memory['turn'] += 1
    memory['cooldown'] = {p: max(0, c-1) for p, c in memory['cooldown'].items()}
    old = memory['old']
    progress = {}
    if old is not None:
        old_positions = {c[2]: i for i, c in enumerate(old) if c[2]}
        for player, square in positions.items():
            before = old[square]
            now = cells[square]
            same = old_positions.get(player) == square
            if same and not before[3] and not now[3] and before[:2] == now[:2]:
                valid_stay = player != me or memory.get('action') != 'SHIELD'
                progress[player] = min(2, memory['progress'].get(player, 0)+1) if valid_stay else 0
            else:
                progress[player] = 0
            if now[3] and not before[3] and same:
                owner = before[0]
                if player == me:
                    source = me if memory.get('action') == 'SHIELD' else owner
                else:
                    source = player if owner in (0, player) else None
                if source:
                    memory['cooldown'][source] = 4
                    if source != me:
                        memory['reaction'].setdefault(source, [2., 2.])[0] += 1
        previous_square = old_positions.get(me)
        if previous_square is not None and memory.get('action') == 'STAY':
            owner = old[previous_square][0]
            if owner not in (0, me) and not old[previous_square][3]:
                if cells[positions[me]][3]:
                    pass  # Already counted as a confirmed shield above.
                elif not memory['cooldown'].get(owner):
                    memory['reaction'].setdefault(owner, [2., 2.])[1] += 1
    if priority:
        memory['token'] = me
    elif memory['token'] is not None:
        memory['token'] = memory['token'] % 4 + 1
    memory['progress'] = progress
    return memory, positions


def paths(start, blocked, legal=None):
    distances = [100]*64
    first = ['STAY']*64
    distances[start] = 0
    queue = deque([start])
    while queue:
        square = queue.popleft()
        for action, target in NEIGHBORS[square]:
            if target in blocked or distances[target] != 100:
                continue
            if square == start and legal is not None and action not in legal:
                continue
            distances[target] = distances[square]+1
            first[target] = action if square == start else first[square]
            queue.append(target)
    return distances, first


def plan(cells, positions, me, memory, legal, deadline):
    remaining = max(1, 81-memory['turn'])
    start = positions[me]
    enemies = [(p, s) for p, s in positions.items() if p != me]
    blocked = {s for p, s in enemies}
    routes = {start: paths(start, blocked, legal)}
    own_mask = sum(1 << i for i, c in enumerate(cells) if c[0] == me)
    upgrade_mask = sum(1 << i for i, c in enumerate(cells) if c[1])
    nearest = [min((DISTANCE[i][s] for p, s in enemies), default=16) for i in range(64)]
    # Search states track projects already completed, preventing duplicate income.
    frontier = [(start, 0, own_mask, upgrade_mask, 0., None)]
    answer, answer_value = 'STAY', 0.
    for depth in range(DEPTH):
        expanded = []
        seen = set()
        for position, elapsed, owned, upgraded, reward, first in frontier:
            if perf_counter() >= deadline:
                return answer, answer_value
            if position not in routes:
                routes[position] = paths(position, blocked)
            distances, actions = routes[position]
            choices = []
            for square, cell in enumerate(cells):
                bit = 1 << square
                is_own = bool(owned & bit)
                is_upgrade = bool(upgraded & bit)
                if distances[square] == 100 or (cell[4] and cell[0] != me) or (is_own and is_upgrade):
                    continue
                stay = 3 if is_own or is_upgrade else 1
                if depth == 0 and square == start:
                    stay = max(1, stay-memory['progress'].get(me, 0))
                cost = distances[square]+stay
                finish = elapsed+cost
                if finish > remaining:
                    continue
                action = first or actions[square]
                if action not in legal:
                    continue
                lifetime = remaining-finish+1
                base = cell[5]
                income = base*lifetime
                bonus = 0.
                delay = 0.
                if is_own:
                    # Level two buys two extra capture turns and extra income.
                    income *= 1 + (0 if cell[4] else ARMOR)
                elif cell[0]:
                    level = 1+is_upgrade
                    bonus = 8*base*level + RAID_WEIGHT*base*level*lifetime
                    if memory['cooldown'].get(cell[0], 0) < finish:
                        yes, no = memory['reaction'].get(cell[0], [2., 2.])
                        probability = yes/(yes+no)
                        income *= 1-SHIELD_RISK*probability
                        bonus *= 1-SHIELD_RISK*probability
                        delay = 3*probability
                else:
                    # Prefer capturing contested neutral income before it disappears.
                    income *= 1.12 if nearest[square] <= distances[square]+2 else 1.
                if not is_own:
                    income *= min(1., .55+.10*nearest[square])
                gain = income+bonus
                if depth == 0 and action not in ('STAY', 'SHIELD'):
                    step = next(t for a,t in NEIGHBORS[start] if a==action)
                    for enemy, location in enemies:
                        if DISTANCE[step][location] != 1 or cells[location][3] or cells[step][0] == me:
                            continue
                        token = memory['token']
                        loses = cells[step][0] == enemy or token is None or (enemy-token)%4 < (me-token)%4
                        if loses:
                            gain *= .80
                total = reward+gain
                rating = total/(finish+delay+1.5)
                choices.append((rating, square, finish, owned|bit,
                                upgraded|bit if is_own else upgraded & ~bit, total, action))
            choices.sort(reverse=True)
            for rating, square, finish, own, levels, total, action in choices[:10]:
                key = square, finish, own, levels, action
                if key not in seen:
                    seen.add(key)
                    expanded.append((rating, (square, finish, own, levels, total, action)))
        if not expanded:
            break
        expanded.sort(key=lambda item: item[0], reverse=True)
        # Keep alternatives for different first actions, even if one dominates now.
        frontier = []
        per_action = {}
        for rating, node in expanded:
            action = node[-1]
            if per_action.get(action, 0) < max(2, WIDTH//3):
                frontier.append(node)
                per_action[action] = per_action.get(action, 0)+1
            if len(frontier) >= WIDTH:
                break
        answer_value, best = expanded[0]
        answer = best[-1]
    return answer, answer_value


def defense(cells, positions, me, memory, remaining):
    missed = 1.
    value = 0.
    for enemy, square in positions.items():
        cell = cells[square]
        if enemy == me or cell[0] != me or cell[3]:
            continue
        progress = memory['progress'].get(enemy, 0)
        probability = .94 if not cell[1] or progress else .75
        imminent = not cell[1] or progress >= 2
        protected_income = cell[5]*(1+cell[1])
        saved = protected_income*(min(remaining, 6)+(.7*remaining if imminent and not cell[4] else 0))
        raid = 8*protected_income if imminent and not cell[4] else 0
        value += probability*(.65*saved+.45*raid+8)
        missed *= 1-probability
    return value-35*missed


def act(state):
    started = perf_counter()
    board = state.board
    flat = [c for row in board for c in row] if len(board)==8 else list(board)
    cells = tuple((c.owner,bool(c.is_upgraded),c.occupant,bool(c.is_frozen),bool(c.is_home),c.base_points) for c in flat)
    me = state.bot_id
    legal = set(state.legal_actions)
    memory, positions = observe(cells, me, legal, state.is_priority_token)
    if me not in positions:
        return 'STAY' if 'STAY' in legal else state.legal_actions[0]
    if cells[positions[me]][3] or legal == {'STAY'}:
        action = 'STAY'
    else:
        action, opportunity = plan(cells, positions, me, memory, legal, started+TIME_BUDGET)
        if 'SHIELD' in legal and defense(cells, positions, me, memory, max(1,81-memory['turn'])) > max(10.,opportunity*.8):
            action = 'SHIELD'
    if action not in legal:
        action = 'STAY' if 'STAY' in legal else state.legal_actions[0]
    memory['action'] = action
    memory['old'] = cells
    return action

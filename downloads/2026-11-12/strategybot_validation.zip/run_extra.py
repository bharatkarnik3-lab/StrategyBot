from arena import run_match,duel
from pathlib import Path
import json
for name in ['bot_dev','mbot']:
 r=duel('bot.py','references/'+name+'.py',range(5300,5304))
 Path('final_'+name+'.json').write_text(json.dumps(r,indent=2)+'\n')
 print(name,{k:v for k,v in r.items() if k!='results'},flush=True)
rows=[]
for path in ['bot.py','references/uploaded.py']:
 results=[]
 for seed in range(5400,5404):
  for seat in range(4):
   files=['baseline:patient']*4;files[seat]=path
   scores,times,stats=run_match(files,seed,telemetry=True)
   own=scores[seat];others=[s for i,s in enumerate(scores) if i!=seat]
   results.append({'seed':seed,'seat':seat+1,'scores':scores,'first':own==max(scores),'points':sum(1 if own>s else .5 if own==s else 0 for s in others),'frozen':stats[seat]['frozen_turns'],'catches':stats[seat]['raid_interruptions'],'max_ms':max(times[seat])*1000})
 summary={'bot':path,'games':len(results),'pairwise':sum(r['points'] for r in results)/(3*len(results)),'first_places':sum(r['first'] for r in results),'mean_score':sum(r['scores'][r['seat']-1] for r in results)/len(results),'mean_frozen':sum(r['frozen'] for r in results)/len(results),'max_repeated':max((v for r in results for v in r['catches'].values()),default=0),'max_ms':max(r['max_ms'] for r in results)}
 print(summary,flush=True);rows.append({'summary':summary,'results':results})
Path('final_stress.json').write_text(json.dumps(rows,indent=2)+'\n')

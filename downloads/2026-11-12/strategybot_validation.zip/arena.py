"""Seat-balanced comparison of two bots, two independent copies of each per game."""
import argparse
import itertools
import json
from pathlib import Path
import time
from simulate import Game, Baseline, load_bot, mirrored_map
from shield_opponents import PatientGuardian


def run_match(files, seed, values=None, strict=True, telemetry=False):
    modules = [load_bot(path, 'player_'+str(i)) if not str(path).startswith('baseline:')
               else (PatientGuardian(seed*31+i) if str(path)=='baseline:patient'
                     else Baseline(str(path).split(':')[1], seed*31+i)) for i,path in enumerate(files)]
    if strict:
        def raise_error():
            raise RuntimeError('Bot caught an internal exception')
        for m in modules:
            if hasattr(m, '_log_exc'):
                m._log_exc = raise_error
    g = Game(values or mirrored_map(seed), priority=seed%4+1)
    times = [[] for _ in range(4)]
    stats = [{"frozen_turns":0,"shields":0,"backfires":0,"raid_interruptions":{}} for _ in range(4)]
    for turn in range(80):
        actions = {}
        for seat, module in enumerate(modules, 1):
            stats[seat-1]["frozen_turns"] += bool(g.frozen[seat])
            state = g.state(seat)
            before = repr(state)
            begin = time.perf_counter()
            action = module.act(state)
            elapsed = time.perf_counter()-begin
            times[seat-1].append(elapsed)
            if action not in state.legal_actions:
                raise AssertionError(('illegal',turn,seat,action))
            if repr(state) != before:
                raise AssertionError(('mutation',turn,seat))
            if elapsed > (2 if turn==0 else .2):
                raise AssertionError(('timeout',turn,seat,elapsed))
            actions[seat] = action
        prior=[None]+[(g.positions[b],g.board[g.positions[b][0]][g.positions[b][1]].owner,
                       g.board[g.positions[b][0]][g.positions[b][1]].is_upgraded,g.frozen[b]) for b in range(1,5)]
        effective=g.step(actions)
        for b in range(1,5):
            position,owner,upgraded,frozen=prior[b]
            if (upgraded and owner not in (0,b) and not frozen and g.frozen[b]
                    and effective[b]=='STAY' and effective.get(owner)=='SHIELD'):
                key=str(owner)+':'+str(position)
                counts=stats[b-1]['raid_interruptions']
                counts[key]=counts.get(key,0)+1
        for seat,action in actions.items():
            if action == "SHIELD":
                stats[seat-1]["shields"] += 1
                stats[seat-1]["backfires"] += bool(g.frozen[seat])
    if telemetry:
        return g.scores[1:], times, stats
    return g.scores[1:], times


def duel(a,b,seeds):
    pairwise=0.;wins=0; margins=[];results=[];timings=[]
    for seed in seeds:
        for seats_a in itertools.combinations(range(4),2):
            files=[a if i in seats_a else b for i in range(4)]
            scores,times,stats=run_match(files,seed,telemetry=True)
            aa=[scores[i] for i in seats_a];bb=[scores[i] for i in range(4) if i not in seats_a]
            points=sum(1 if x>y else .5 if x==y else 0 for x in aa for y in bb)
            pairwise+=points
            wins+=sum(x==max(scores) for x in aa)
            margins.append(sum(aa)/2-sum(bb)/2)
            timings.extend(t for i in seats_a for t in times[i])
            results.append({'seed':seed,'a_seats':[i+1 for i in seats_a],'scores':scores,'a_pairwise_points':points,'a_frozen_turns':sum(stats[i]['frozen_turns'] for i in seats_a),
                            'b_frozen_turns':sum(stats[i]['frozen_turns'] for i in range(4) if i not in seats_a),
                            'a_max_repeated_catches':max((v for i in seats_a for v in stats[i]['raid_interruptions'].values()),default=0),
                            'b_max_repeated_catches':max((v for i in range(4) if i not in seats_a for v in stats[i]['raid_interruptions'].values()),default=0)})
    timings.sort()
    return {'a':str(a),'b':str(b),'games':len(results),'a_pairwise_rate':pairwise/(len(results)*4),
            'a_first_places':wins,'a_mean_margin':sum(margins)/len(margins),
            'a_p95_ms':timings[int(.95*(len(timings)-1))]*1000,'a_max_ms':max(timings)*1000,
            'a_mean_frozen_turns':sum(r['a_frozen_turns'] for r in results)/(2*len(results)),
            'b_mean_frozen_turns':sum(r['b_frozen_turns'] for r in results)/(2*len(results)),
            'a_max_repeated_catches':max(r['a_max_repeated_catches'] for r in results),
            'b_max_repeated_catches':max(r['b_max_repeated_catches'] for r in results),
            'results':results}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('a');p.add_argument('b');p.add_argument('--seed',type=int,default=0);p.add_argument('--maps',type=int,default=4);p.add_argument('--output');args=p.parse_args()
    if args.maps<1:p.error('--maps must be positive')
    r=duel(args.a,args.b,range(args.seed,args.seed+args.maps))
    if args.output:Path(args.output).write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k!='results'},indent=2),flush=True)

if __name__=='__main__':main()

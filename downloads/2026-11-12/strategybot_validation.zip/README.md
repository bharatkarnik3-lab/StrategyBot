# Validation bundle

Use only bot.py for submission. References and test tools are for local validation.
Python 3.10+; no third-party dependencies.

```
python -B -m unittest discover -p 'test_*.py' -v
python -B arena.py bot.py references/uploaded.py --seed 5100 --maps 12 --output rerun_uploaded.json
python -B arena.py bot.py references/previous.py --seed 5200 --maps 8 --output rerun_previous.json
python -B arena.py bot.py references/bot_dev.py --seed 5300 --maps 4 --output rerun_dev.json
python -B arena.py bot.py references/mbot.py --seed 5300 --maps 4 --output rerun_mbot.json
```

See REPORT.md for research sources, methods and limitations. Each map takes six games.

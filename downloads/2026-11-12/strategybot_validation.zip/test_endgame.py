"""Finite-horizon decisions, occupancy and safe search-budget fallback."""
from pathlib import Path
import time
import unittest
from unittest.mock import patch

from simulate import Game, load_bot

HERE = Path(__file__).resolve().parent


class EndgameTests(unittest.TestCase):
    def setUp(self):
        self.bot = load_bot(HERE / 'bot.py', 'endgame_tests_bot')
        self.g = Game([[1] * 8 for _ in range(8)])
        # Closed, fully developed position with only the named raid projects.
        for row in self.g.board:
            for cell in row:
                if not cell.is_home:
                    cell.owner, cell.is_upgraded = 1, True
        self.g.positions[1] = (3, 3)

    def context(self, turn=78):
        snap = self.bot.Snap(self.g.state(1))
        mem = self.bot.Memory(snap)
        mem.turn = turn
        mem.last_shield[2] = mem.last_shield[3] = turn - 1
        return self.bot._build_ctx(mem, snap)

    def raid(self, pos, owner, value):
        cell = self.g.board[pos[0]][pos[1]]
        cell.owner, cell.is_upgraded, cell.base_points = owner, False, value

    def test_maximizes_remaining_total_instead_of_capture_rate(self):
        self.raid((3, 3), 2, 1)
        self.raid((3, 1), 3, 3)
        c = self.context()
        here = self.bot._evaluate(c, 27, self.bot.RAID1, 0, 0, c.t, c.s.own, c.s.lvl)
        far = self.bot._evaluate(c, 25, self.bot.RAID1, 2, 0, c.t, c.s.own, c.s.lvl)
        self.assertGreater(here[0] / here[1], far[0] / far[1])
        self.assertGreater(far[0], here[0])
        action = self.bot._decide(c.mem, c.s, time.perf_counter())
        self.assertEqual(action, 'WEST')

    def test_occupied_shortcut_cannot_make_unreachable_raid_win(self):
        self.raid((3, 3), 2, 1)
        self.raid((3, 1), 3, 3)
        self.g.positions[4] = (3, 2)
        c = self.context()
        self.assertEqual(c.dme[25], 4)
        self.assertEqual(self.bot._decide(c.mem, c.s, time.perf_counter()), 'STAY')

    def test_captured_square_only_contributes_one_raid_bonus(self):
        self.raid((3, 3), 2, 3)
        c = self.context(turn=74)
        u, k = self.bot._evaluate(c, 27, self.bot.RAID1, 0, 0, c.t, c.s.own, c.s.lvl)
        own, lvl = self.bot._apply(c, c.s.own, c.s.lvl, 27, self.bot.RAID1)
        upgrade = self.bot._evaluate(c, 27, self.bot.UPGRADE, 0, 0, c.t + 1, own, lvl)
        ranked = self.bot._plan(c, time.perf_counter() + 1)
        self.assertEqual(ranked[0][1:3], (27, self.bot.RAID1))
        self.assertAlmostEqual(ranked[0][0], u + max(0, upgrade[0]))
        self.assertEqual(c.s.own[27], 2)  # hypothetical boards never mutate snapshot

    def test_followup_route_respects_occupied_square(self):
        self.raid((3, 3), 2, 1)
        self.raid((3, 1), 3, 3)
        self.g.positions[4] = (3, 2)
        c = self.context(turn=77)
        u, k = self.bot._evaluate(c, 27, self.bot.RAID1, 0, 0, c.t, c.s.own, c.s.lvl)
        own, lvl = self.bot._apply(c, c.s.own, c.s.lvl, 27, self.bot.RAID1)
        upgrade = self.bot._evaluate(c, 27, self.bot.UPGRADE, 0, 0, c.t + 1, own, lvl)
        ranked = self.bot._endgame_plan(c, [(u / k, u, k, 27, self.bot.RAID1)],
                                        time.perf_counter() + 1)
        self.assertAlmostEqual(ranked[0][0], u + max(0, upgrade[0]))

    def test_expired_budget_retains_valid_best_single_project(self):
        self.raid((3, 3), 2, 1)
        self.raid((3, 1), 3, 3)
        c = self.context()
        first = []
        for x, d in ((27, 0), (25, 2)):
            u, k = self.bot._evaluate(c, x, self.bot.RAID1, d, 0, c.t, c.s.own, c.s.lvl)
            first.append((u / k, u, k, x, self.bot.RAID1))
        with patch.object(self.bot, '_evaluate', side_effect=AssertionError('budget exhausted')):
            ranked = self.bot._endgame_plan(c, first, time.perf_counter() - 1)
        self.assertEqual(ranked[0][1], 25)
        self.assertEqual(len(ranked), 2)
        self.assertEqual(self.bot._step_toward(c, ranked[0][1]), 'WEST')


if __name__ == '__main__':
    unittest.main()

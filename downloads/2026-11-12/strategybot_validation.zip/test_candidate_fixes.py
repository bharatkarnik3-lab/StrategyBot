"""Focused public-rule regressions for the standalone corrected bot."""
import copy
from pathlib import Path
import time
import unittest

from simulate import Baseline, Game, load_bot, play

HERE = Path(__file__).resolve().parent


class TrackerAndShieldTests(unittest.TestCase):
    def setUp(self):
        self.bot = load_bot(HERE / 'bot.py', 'corrected_bot')
        self.game = Game([[1] * 8 for _ in range(8)])

    def act(self, legal=None):
        state = self.game.state(1)
        if legal is not None:
            state.legal_actions = legal
        before = copy.deepcopy(state)
        action = self.bot.act(state)
        self.assertIn(action, state.legal_actions)
        self.assertEqual(state, before)
        return action

    def test_own_backfire_does_not_invent_foreign_owner_shield(self):
        g = self.game
        g.positions[1] = (1, 1)
        g.board[1][1].owner = 2
        g.positions[3] = (2, 2)
        g.board[2][2].owner, g.board[2][2].base_points = 1, 3
        self.assertEqual(self.act(), 'SHIELD')
        g.step({1: 'SHIELD', 3: 'EAST'})
        self.act()
        self.assertEqual(g.frozen[1], 2)
        self.assertEqual(self.bot._MEM.inferred, [1])
        self.assertEqual(self.bot._MEM.last_shield[2], -100)
        self.assertEqual(self.bot._MEM.prog[1], 0)

    def test_ambiguous_rival_backfire_does_not_invent_cooldowns(self):
        g = self.game
        g.positions[2] = (2, 2)
        g.board[2][2].owner = 3
        action = self.act()
        g.step({1: action, 2: 'SHIELD'})
        self.act()
        self.assertEqual(self.bot._MEM.last_shield[2], -100)
        self.assertEqual(self.bot._MEM.last_shield[3], -100)
        self.assertEqual(self.bot._MEM.stats[3]['opp'], 0)

    def test_known_own_shield_is_attributed(self):
        g = self.game
        g.positions[2] = (2, 2)
        g.board[2][2].owner, g.board[2][2].base_points = 1, 3
        self.assertEqual(self.act(), 'SHIELD')
        g.step({1: 'SHIELD', 2: 'STAY'})
        self.act()
        self.assertEqual(self.bot._MEM.inferred, [1])
        self.assertEqual(self.bot._MEM.last_shield[1], 1)
        self.assertEqual(self.bot._MEM.prog[2], 0)

    def endgame(self, upgraded, progress):
        g = self.game
        g.positions[1] = (3, 3)
        g.board[3][3].base_points = 3
        g.positions[2] = (4, 4)
        cell = g.board[4][4]
        cell.owner, cell.base_points, cell.is_upgraded = 1, 3, upgraded
        snap = self.bot.Snap(g.state(1))
        mem = self.bot.Memory(snap)
        mem.turn, mem.prog[2] = 80, progress
        return snap, mem

    def test_last_turn_ignores_unfinishable_raid(self):
        snap, mem = self.endgame(True, 1)
        self.assertEqual(self.bot._decide(mem, snap, time.perf_counter()), 'STAY')

    def test_last_turn_can_block_imminent_raid(self):
        snap, mem = self.endgame(True, 2)
        self.assertEqual(self.bot._decide(mem, snap, time.perf_counter()), 'SHIELD')

    def test_frozen_turns_and_thaw_do_not_build_progress(self):
        g = self.game
        g.positions[1] = (1, 1)
        g.board[1][1].owner, g.board[1][1].is_upgraded = 2, True
        self.act(['STAY'])
        g.step({1: 'STAY', 2: 'SHIELD'})
        for _ in range(2):
            self.act()
            self.assertEqual(self.bot._MEM.prog[1], 0)
            self.assertFalse(self.bot._MEM.fz_prog)
            g.step({1: 'STAY'})
        self.act(['STAY'])
        self.assertEqual(self.bot._MEM.prog[1], 0)
        g.step({1: 'STAY'})
        self.act(['STAY'])
        self.assertEqual(self.bot._MEM.prog[1], 1)

    def test_full_game_legal_timing_and_immutability(self):
        controllers = [self.bot, Baseline('fortress'), Baseline('upgrade'), Baseline('raider')]
        game, _ = play(controllers, seed=11, check_inputs=True)
        self.assertEqual(game.turn, 80)


if __name__ == '__main__':
    unittest.main()
